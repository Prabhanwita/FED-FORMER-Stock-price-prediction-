# FEDformer NIFTY 50 Dashboard

A Streamlit dashboard for visualising FEDformer stock price forecasting results.

## How to Run on Your Device

### Step 1 — Install Python (if not already installed)
Download Python 3.10 or 3.11 from https://www.python.org/downloads/
Make sure to check "Add Python to PATH" during installation.

### Step 2 — Open Terminal / Command Prompt
- Windows: Press Win+R → type `cmd` → Enter
- Mac/Linux: Open Terminal

### Step 3 — Install dependencies
```
pip install streamlit plotly pandas numpy yfinance scikit-learn
```

### Step 4 — Run the dashboard
Navigate to the folder containing app.py and run:
```
streamlit run app.py
```

The dashboard will automatically open in your browser at:
http://localhost:8501

### Step 5 — Share with your supervisor
If you want to share the dashboard as a live URL:
1. Create a free account at https://streamlit.io/cloud
2. Push your code to a GitHub repository
3. Deploy from Streamlit Cloud — free hosting, live URL

---

## Dashboard Pages

| Page | Description |
|------|-------------|
| Overview | Summary metrics, model comparison table, sector pie chart |
| Stock Analysis | Live price fetch, BUY/SELL/HOLD signal, risk manager, candlestick chart |
| Sector Analysis | Sector-aware frequency modes visualisation |
| Model Comparison | FEDformer vs Autoformer vs PatchTST scatter plot |
| Backtesting | Simulation results and portfolio curve |
| About | Project details, team, technical parameters |

---

## Project
KIIT University — Group 5
FEDformer: Frequency Enhanced Decomposed Transformer for NIFTY 50 Stock Price Forecasting
Supervisor: Dr. Ambika Prasad Mishra
